//
//  ViewController.swift
//  app_class
//
//  Created by Kondepati,Sai Bharath on 9/5/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var label: UIView!
    
    @IBOutlet weak var input1: UITextField!
    
    
    @IBOutlet weak var input2: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func clkbtm(_ sender: UIButton) {
        
        let input = input1.text!
        
        let age = Double(input) ?? 0
        
        if(age>=18){
            input2.text = "The person is eligible for voting"
            
        }
        else
        {
            input2.text = "The person is not eligible for voting"
        }
    }
    
}

